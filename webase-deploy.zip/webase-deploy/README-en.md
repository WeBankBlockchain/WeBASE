# Quick build
## Introduction

One-click deployment quickly builds A WeBASE management desk environment. Includes node (FISCO-BCOS 2.0), node front subsystem (WeBASE-Front), private key and sign managerment subsystem (WeBASE-Sign), node management subsystem (WeBASE-Node-Manager), management platform (WeBASE-Web). Among them, the configuration of the node is optional, you can choose to use the existing chain or build a new chain. For more information, check out the online documentation for one-click deployment (https://webasedoc.readthedocs.io/zh_CN/latest/docs/WeBASE/install.html).

## A description of the contribution
Read our contribution documentation to learn how to contribute code and submit your contribution.

Hopefully with your participation, WeBASE will get better and better!

## The community
Contact us: webase@webank.com
